const mongoose = require('mongoose');

const ProjectSchema = new mongoose.Schema({
    project:{
        type:String,
        required:true
    },
    category:{
        type:[String],
        required:true
    }
});

module.exports = Project = mongoose.model('Project', ProjectSchema);