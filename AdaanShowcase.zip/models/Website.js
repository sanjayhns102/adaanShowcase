const mongoose = require('mongoose');

const WebsiteSchema = new mongoose.Schema({
    user:{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'users'
    },
    name:{
        type: String,
        required: true
    },
    projectName:{
        type: String,
        required: true
    },
    categories:{
        type: String,
        required: true
    },
    pages:{
        type: Number,
        required: true
    },
    SiteURL:{
        type: String,
        required: true
    },
    ImageURL:{
        type: String,
        required: true
    },date:{
        type:Date,
        default:Date.now
    }
});

module.exports = Websites =mongoose.model('Website', WebsiteSchema);