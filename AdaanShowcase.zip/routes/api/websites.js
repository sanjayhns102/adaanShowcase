const express = require("express");
const router = express.Router();
const Website = require("../../models/Website");
const auth = require("../../middleware/auth");
const { check, validationResult } = require("express-validator");
const User = require('../../models/User');


//@route   GET  api/websites
//@desc    Get all websites
//access   Public
router.get('/', async(req,res)=>{
    try{
        const websites = await Website.find();
        res.json(websites);
        console.log(websites)
    }catch(err){
        console.log(err);
        res.status(500).send('server error')
    }
});

//@route   GET  api/websites/my
//@desc    Get my all websites
//access   Private
router.get('/my', auth, async(req,res)=>{
  try{
      const websites = await Website.find({user:req.user.id});
      res.json(websites);
      console.log(websites)
  }catch(err){
      console.log(err);
      res.status(500).send('server error')
  }
});

//@route   POST  api/websites
//@desc    Post the Website
//access   Private
router.post(
  "/", auth,
  [
    check("projectName", "projectName is required").not().isEmpty(),
    check("categories", "categories is required").not().isEmpty(),
    check("pages", "pages is required").not().isEmpty(),
    check("SiteURL", "Website url is required").not().isEmpty(),
    check("ImageURL", "Image url is required").not().isEmpty()
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const user = await User.findById(req.user.id).select('-password');
    const {
        projectName,
        categories,
        pages,
        SiteURL,
        ImageURL,
        Designer
    } = req.body;

    try{
        //Create new site
        const newSite = {
          user:user.id,
          name: user.name,
          projectName:projectName,
          categories:categories,
          pages:pages,
          SiteURL:SiteURL,
          ImageURL:ImageURL
        };
        console.log("creating new Site")
      site = new Website(newSite);
      const website =  await site.save();
        return res.json(website);
    }catch(err){
        console.error(err.message);
      res.status(500).send('server error');
    }
});


module.exports = router;