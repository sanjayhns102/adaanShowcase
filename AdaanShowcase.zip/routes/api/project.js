const express = require('express');
const router = express.Router();
const Project = require('../../models/Project');
const auth = require('../../middleware/auth');


//@route   GET  api/project
//@desc    Get project list
//access   Private
router.get('/', auth, async (req,res) => {
    try {
        const project = await Project.find();

        if(project.length==0){
            return res.status(400).json({msg:'There is no project'})
        }
        res.json(project);
    } catch (err) {
        res.status(500).send('server error')
    }
})


//@route   POST  api/project
//@desc    Add a new Project
//access   Private
router.post('/', async (req,res)=>{

    const {project, category} = req.body;
    const newProject = {
        project,
        category
    };
    try {
        projects = new Project(newProject);
        await projects.save();
        return res.json(projects)
    } catch (err) {
        console.log(err);
        res.status(500).send('server error')
    }
});

module.exports = router;